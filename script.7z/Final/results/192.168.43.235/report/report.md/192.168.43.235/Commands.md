```bash
nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/eni9ma/routersploit/results/192.168.43.235/scans/_quick_tcp_nmap.txt" -oX "/home/eni9ma/routersploit/results/192.168.43.235/scans/xml/_quick_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/routersploit/results/192.168.43.235/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/routersploit/results/192.168.43.235/scans/xml/_full_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/routersploit/results/192.168.43.235/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/routersploit/results/192.168.43.235/scans/xml/_top_100_udp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_quick_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_quick_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_full_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_top_100_udp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_quick_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_quick_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_full_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_top_100_udp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_quick_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_quick_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_full_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_top_100_udp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_quick_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_quick_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_full_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_top_100_udp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_quick_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_quick_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_full_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_top_100_udp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_quick_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_quick_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_full_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_top_100_udp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -p 35027 --script="banner,(mongodb* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN "/home/eni9ma/Final/results/192.168.43.235/scans/tcp35027/tcp_35027_mongodb_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/tcp35027/xml/tcp_35027_mongodb_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_quick_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_quick_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_full_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_top_100_udp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_quick_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_quick_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_full_tcp_nmap.xml" 192.168.43.235

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/Final/results/192.168.43.235/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.235/scans/xml/_top_100_udp_nmap.xml" 192.168.43.235


```