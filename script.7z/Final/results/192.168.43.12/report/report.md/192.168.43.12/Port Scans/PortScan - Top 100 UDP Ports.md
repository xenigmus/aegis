```bash
nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/eni9ma/Final/results/192.168.43.12/scans/_top_100_udp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.12/scans/xml/_top_100_udp_nmap.xml" 192.168.43.12
```

[/home/eni9ma/Final/results/192.168.43.12/scans/_top_100_udp_nmap.txt](file:///home/eni9ma/Final/results/192.168.43.12/scans/_top_100_udp_nmap.txt):

```
# Nmap 7.94SVN scan initiated Mon Apr 29 10:45:59 2024 as: nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN /home/eni9ma/Final/results/192.168.43.12/scans/_top_100_udp_nmap.txt -oX /home/eni9ma/Final/results/192.168.43.12/scans/xml/_top_100_udp_nmap.xml 192.168.43.12
Nmap scan report for 192.168.43.12 [host down, received no-response]
Read data files from: /usr/bin/../share/nmap
# Nmap done at Mon Apr 29 10:46:01 2024 -- 1 IP address (0 hosts up) scanned in 3.16 seconds

```
