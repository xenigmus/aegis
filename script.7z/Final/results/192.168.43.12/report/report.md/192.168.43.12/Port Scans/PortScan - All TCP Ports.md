```bash
nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/eni9ma/Final/results/192.168.43.12/scans/_full_tcp_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.12/scans/xml/_full_tcp_nmap.xml" 192.168.43.12
```

[/home/eni9ma/Final/results/192.168.43.12/scans/_full_tcp_nmap.txt](file:///home/eni9ma/Final/results/192.168.43.12/scans/_full_tcp_nmap.txt):

```
# Nmap 7.94SVN scan initiated Mon Apr 29 10:45:59 2024 as: nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN /home/eni9ma/Final/results/192.168.43.12/scans/_full_tcp_nmap.txt -oX /home/eni9ma/Final/results/192.168.43.12/scans/xml/_full_tcp_nmap.xml 192.168.43.12
Nmap scan report for 192.168.43.12 [host down, received no-response]
Read data files from: /usr/bin/../share/nmap
# Nmap done at Mon Apr 29 10:46:01 2024 -- 1 IP address (0 hosts up) scanned in 3.14 seconds

```
