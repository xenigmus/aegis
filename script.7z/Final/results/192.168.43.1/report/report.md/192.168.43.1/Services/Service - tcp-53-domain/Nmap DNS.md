```bash
nmap -vv --reason -Pn -T4 -sV -p 53 --script="banner,(dns* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN "/home/eni9ma/Final/results/192.168.43.1/scans/tcp53/tcp_53_dns_nmap.txt" -oX "/home/eni9ma/Final/results/192.168.43.1/scans/tcp53/xml/tcp_53_dns_nmap.xml" 192.168.43.1
```

[/home/eni9ma/Final/results/192.168.43.1/scans/tcp53/tcp_53_dns_nmap.txt](file:///home/eni9ma/Final/results/192.168.43.1/scans/tcp53/tcp_53_dns_nmap.txt):

```
# Nmap 7.94SVN scan initiated Tue Apr 30 11:40:22 2024 as: nmap -vv --reason -Pn -T4 -sV -p 53 "--script=banner,(dns* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN /home/eni9ma/Final/results/192.168.43.1/scans/tcp53/tcp_53_dns_nmap.txt -oX /home/eni9ma/Final/results/192.168.43.1/scans/tcp53/xml/tcp_53_dns_nmap.xml 192.168.43.1
Nmap scan report for 192.168.43.1
Host is up, received arp-response (0.0036s latency).
Scanned at 2024-04-30 11:40:35 IST for 21s

PORT   STATE SERVICE REASON         VERSION
53/tcp open  domain  syn-ack ttl 64 dnsmasq 2.51
| dns-nsid: 
|_  bind.version: dnsmasq-2.51
|_dns-nsec-enum: Can't determine domain for host 192.168.43.1; use dns-nsec-enum.domains script arg.
|_dns-nsec3-enum: Can't determine domain for host 192.168.43.1; use dns-nsec3-enum.domains script arg.
MAC Address: 0A:2F:E6:1E:43:9D (Unknown)

Host script results:
|_dns-brute: Can't guess domain of "192.168.43.1"; use dns-brute.domain script argument.

Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Tue Apr 30 11:40:56 2024 -- 1 IP address (1 host up) scanned in 34.67 seconds

```
