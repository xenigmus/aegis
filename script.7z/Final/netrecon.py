#!/usr/bin/python3

from autorecon.main import main

if __name__ == '__main__':
	main()
